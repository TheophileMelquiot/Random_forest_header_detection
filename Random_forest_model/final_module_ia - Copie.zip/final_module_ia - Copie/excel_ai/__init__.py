from .detector import detect_headers
from .services.extraction_service import detect_and_load

__all__ = ["detect_headers", "detect_and_load"]
# excel_ai/services/extraction_service.py

import pandas as pd
from typing import Dict
from ..detector import detect_headers


def detect_and_load(
    filepath: str,
    threshold: float = 0.35
) -> Dict[str, pd.DataFrame]:
    """
    Detect headers and return cleaned DataFrames per sheet.
    """

    headers = detect_headers(filepath, threshold)

    dfs = {}

    for sheet_name, header_row in headers.items():
        try:
            df = pd.read_excel(
                filepath,
                sheet_name=sheet_name,
                header=header_row - 1
            )
            dfs[sheet_name] = df

        except Exception:
            continue

    return dfs